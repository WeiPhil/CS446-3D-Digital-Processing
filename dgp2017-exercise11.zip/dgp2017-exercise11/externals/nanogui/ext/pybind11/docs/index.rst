.. only: not latex

    .. image:: pybind11-logo.png

pybind11 --- Seamless operability between C++11 and Python
==========================================================

.. only: not latex

    Contents:

.. toctree::
   :maxdepth: 2

   intro
   basics
   classes
   advanced
   compiling
   benchmark
   limitations
   faq
   reference
   changelog
