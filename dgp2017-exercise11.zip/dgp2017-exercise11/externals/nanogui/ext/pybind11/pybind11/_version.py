version_info = (1, 9, 'dev0')
__version__ = '.'.join(map(str, version_info))
